# Selfbot + Protect PY3 WROKS Need update
 
HOW TO RUN VIA VPS ( VIRTUAL PRIVATE SERVER )
1. sudo apt-get install git
2. git clone https://github.com/arifistifik/dpk
3. sudo apt-get python3-pip
4. sude pip3 install rsa
5. sudo pip3 install requests
6. sudo pip3 install googletrans
7. sudo pip3 install bs4
8. sudo pip3 install requests
9 .sudo pip3 install rsa
10. sudo pip3 install thrift
11. sudo pip3 install bs4
12. sudo pip3 install pytz
13. sudo pip3 install humanfriendly
14. sudo pip3 install gtts
15. sudo pip3 install googletrans
16. sudo pip3 install wikipedia
17. sudo pip3 install youtube_dl
18. sudo pip3 install ffmpy
19. cd dpk
20. python3 sb.py


HOW TO RUN VIA TERMUX ( TERMINAL LINUX )
1. pkg install git
2. pkg install akad
3. git clone https://github.com/arifistifik/dpk
4. pkg install python3-pip
5. pip3 install rsa
6. pip3 install requests
7. pip3 install googletrans
8. pip3 install bs4
9. pip3 install requests
10 .pip3 install rsa
11. pip3 install thrift
12. pip3 install bs4
13. pip3 install pytz
14. pip3 install humanfriendly
15. pip3 install gtts
16. pip3 install googletrans
17. pip3 install wikipedia
18. pip3 install youtube_dl
19. pip3 install ffmpy
20. cd dpk
21. python3 sb.py

